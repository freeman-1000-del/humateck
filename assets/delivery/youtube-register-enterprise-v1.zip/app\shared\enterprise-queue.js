(function () {
  "use strict";

  var queue = [];
  var running = false;

  function $(id) {
    return document.getElementById(id);
  }

  function setQueueStatus(text) {
    var el = $("queueStatus");
    if (el) el.textContent = text || "";
  }

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/"/g, "&quot;");
  }

  function countLangs(text) {
    if (window.HumateckYouTubeRegister && window.HumateckYouTubeRegister.parse) {
      return Object.keys(window.HumateckYouTubeRegister.parse(text)).length;
    }
    return 0;
  }

  function renderTable() {
    var tbody = $("queueBody");
    if (!tbody) return;
    tbody.innerHTML = "";
    queue.forEach(function (item, idx) {
      var tr = document.createElement("tr");
      tr.innerHTML =
        "<td>" +
        (idx + 1) +
        "</td>" +
        '<td title="' +
        escapeHtml(item.videoUrl) +
        '">' +
        escapeHtml(item.videoUrl.slice(0, 48)) +
        (item.videoUrl.length > 48 ? "…" : "") +
        "</td>" +
        "<td>" +
        (item.langCount || "—") +
        "</td>" +
        "<td>" +
        item.status +
        "</td>" +
        '<td><button type="button" class="btn" data-remove="' +
        idx +
        '">삭제</button></td>';
      tbody.appendChild(tr);
    });
    tbody.querySelectorAll("[data-remove]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        queue.splice(parseInt(btn.getAttribute("data-remove"), 10), 1);
        renderTable();
      });
    });
  }

  function addToQueue() {
    var videoUrl = ($("videoUrl") && $("videoUrl").value) || "";
    var finalOutput = ($("finalOutput") && $("finalOutput").value) || "";
    if (!videoUrl.trim() || !finalOutput.trim()) {
      alert("영상 URL과 Final Registration Command를 입력하세요.");
      return;
    }
    queue.push({
      videoUrl: videoUrl.trim(),
      finalOutput: finalOutput.trim(),
      nativeLanguageCode: ($("nativeLanguageCode") && $("nativeLanguageCode").value) || "ko",
      sourceTitle: ($("sourceTitle") && $("sourceTitle").value) || "",
      sourceDescription: ($("sourceDescription") && $("sourceDescription").value) || "",
      langCount: countLangs(finalOutput),
      status: "대기",
    });
    renderTable();
    setQueueStatus("대기열 " + queue.length + "건");
  }

  function applyJob(job) {
    $("videoUrl").value = job.videoUrl;
    $("finalOutput").value = job.finalOutput;
    if ($("nativeLanguageCode")) $("nativeLanguageCode").value = job.nativeLanguageCode || "ko";
    if ($("sourceTitle")) $("sourceTitle").value = job.sourceTitle || "";
    if ($("sourceDescription")) $("sourceDescription").value = job.sourceDescription || "";
  }

  async function runQueue() {
    if (running || !queue.length) return;
    if (!window.humateckGoogleAccessToken) {
      alert("먼저 Google OAuth 인증을 완료하세요.");
      return;
    }
    if (!window.HumateckYouTubeRegister || !window.HumateckYouTubeRegister.deliver) return;

    running = true;
    if ($("queueRunBtn")) $("queueRunBtn").disabled = true;
    if ($("sendOrderBtn")) $("sendOrderBtn").disabled = true;

    for (var i = 0; i < queue.length; i++) {
      if (queue[i].status === "완료") continue;
      queue[i].status = "진행 중";
      renderTable();
      setQueueStatus("처리 중 " + (i + 1) + "/" + queue.length);
      applyJob(queue[i]);
      try {
        await window.HumateckYouTubeRegister.deliver();
        queue[i].status = "완료";
      } catch (e) {
        queue[i].status = "오류";
      }
      renderTable();
      await new Promise(function (r) {
        setTimeout(r, 800);
      });
    }

    running = false;
    if ($("queueRunBtn")) $("queueRunBtn").disabled = false;
    if ($("sendOrderBtn")) $("sendOrderBtn").disabled = false;
    setQueueStatus("대기열 완료");
  }

  function clearQueue() {
    if (running) return;
    queue = [];
    renderTable();
    setQueueStatus("비움");
  }

  document.addEventListener("DOMContentLoaded", function () {
    var addBtn = $("queueAddBtn");
    var runBtn = $("queueRunBtn");
    var clearBtn = $("queueClearBtn");
    if (addBtn) addBtn.addEventListener("click", addToQueue);
    if (runBtn) runBtn.addEventListener("click", runQueue);
    if (clearBtn) clearBtn.addEventListener("click", clearQueue);
    renderTable();
  });
})();
