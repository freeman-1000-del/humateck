﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop-server.ps1"
echo.
echo  Humateck ?쒕쾭瑜?醫낅즺?덉뒿?덈떎.
pause
