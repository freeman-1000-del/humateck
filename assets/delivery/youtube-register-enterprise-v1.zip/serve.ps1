param(
  [int]$Port = 8765,
  [string]$Root = $PSScriptRoot
)

$Root = (Resolve-Path $Root).Path
$prefix = "http://localhost:$Port/"

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)

try {
  $listener.Start()
} catch {
  Write-Host "포트 $Port 사용 중입니다. 다른 창을 닫거나 포트를 바꾸세요." -ForegroundColor Red
  exit 1
}

Write-Host "Humateck PC 등록기 — $prefix" -ForegroundColor Cyan
Write-Host "폴더: $Root" -ForegroundColor DarkGray
Write-Host "종료: Ctrl+C" -ForegroundColor DarkGray

while ($listener.IsListening) {
  $context = $listener.GetContext()
  $request = $context.Request
  $response = $context.Response

  $rel = $request.Url.LocalPath.TrimStart("/")
  $rel = $rel.TrimEnd("/")
  if ([string]::IsNullOrWhiteSpace($rel)) { $rel = "index.html" }
  $rel = $rel -replace "/", [IO.Path]::DirectorySeparatorChar
  $file = [IO.Path]::GetFullPath((Join-Path $Root $rel))

  if (-not $file.StartsWith($Root, [StringComparison]::OrdinalIgnoreCase)) {
    $response.StatusCode = 403
    $msg = [Text.Encoding]::UTF8.GetBytes("403 Forbidden")
    $response.OutputStream.Write($msg, 0, $msg.Length)
    $response.Close()
    continue
  }

  if (Test-Path $file -PathType Container) {
    $file = Join-Path $file "index.html"
  }

  if (Test-Path $file -PathType Leaf) {
    $bytes = [IO.File]::ReadAllBytes($file)
    $ext = [IO.Path]::GetExtension($file).ToLower()
    $mime = switch ($ext) {
      ".html" { "text/html; charset=utf-8" }
      ".js"   { "application/javascript; charset=utf-8" }
      ".css"  { "text/css; charset=utf-8" }
      ".json" { "application/json; charset=utf-8" }
      ".md"   { "text/plain; charset=utf-8" }
      default { "application/octet-stream" }
    }
    $response.ContentType = $mime
    $response.ContentLength64 = $bytes.Length
    $response.OutputStream.Write($bytes, 0, $bytes.Length)
  } else {
    $response.StatusCode = 404
    $msg = [Text.Encoding]::UTF8.GetBytes("404 Not Found")
    $response.OutputStream.Write($msg, 0, $msg.Length)
  }

  $response.Close()
}
