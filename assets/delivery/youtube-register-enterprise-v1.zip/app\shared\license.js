(function () {
  "use strict";

  var STORAGE_KEY = "humateckPcLicense";
  var MACHINE_KEY = "humateckPcMachineId";
  var ENT_ACT_KEY = "humateckEntActivations";

  function getMachineId() {
    try {
      var id = localStorage.getItem(MACHINE_KEY);
      if (!id) {
        id =
          "m" +
          Date.now().toString(36) +
          Math.random().toString(36).slice(2, 10);
        localStorage.setItem(MACHINE_KEY, id);
      }
      return id;
    } catch (e) {
      return "offline-machine";
    }
  }

  function parseKey(key) {
    var raw = String(key || "")
      .trim()
      .toUpperCase();
    if (/^HMT-STD-[A-Z0-9]{6,12}$/.test(raw)) {
      return { edition: "standard", key: raw, maxPc: 1 };
    }
    if (/^HMT-ENT-[A-Z0-9]{6,12}$/.test(raw)) {
      return { edition: "enterprise", key: raw, maxPc: 5 };
    }
    return null;
  }

  function loadLicense() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  }

  function saveLicense(data) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {}
  }

  function loadEntActivations(licenseKey) {
    try {
      var raw = localStorage.getItem(ENT_ACT_KEY);
      var all = raw ? JSON.parse(raw) : {};
      return all[licenseKey] || [];
    } catch (e) {
      return [];
    }
  }

  function saveEntActivation(licenseKey, machineId) {
    try {
      var raw = localStorage.getItem(ENT_ACT_KEY);
      var all = raw ? JSON.parse(raw) : {};
      var list = all[licenseKey] || [];
      if (list.indexOf(machineId) < 0) list.push(machineId);
      all[licenseKey] = list;
      localStorage.setItem(ENT_ACT_KEY, JSON.stringify(all));
    } catch (e) {}
  }

  function activate(licenseKey, expectedEdition) {
    var parsed = parseKey(licenseKey);
    if (!parsed) {
      return { ok: false, error: "라이선스 형식이 올바르지 않습니다. (HMT-STD-… / HMT-ENT-…)" };
    }
    if (expectedEdition && parsed.edition !== expectedEdition) {
      return {
        ok: false,
        error:
          parsed.edition === "enterprise"
            ? "이 키는 기업용입니다. 기업용 프로그램을 사용하세요."
            : "이 키는 일반용입니다. 일반용 프로그램을 사용하세요.",
      };
    }

    var machineId = getMachineId();
    var existing = loadLicense();

    if (parsed.edition === "standard") {
      if (
        existing &&
        existing.key !== parsed.key &&
        existing.machineId &&
        existing.machineId !== machineId
      ) {
        return { ok: false, error: "이 일반용 키는 이미 다른 PC에 등록되었습니다." };
      }
    }

    if (parsed.edition === "enterprise") {
      var activations = loadEntActivations(parsed.key);
      if (
        activations.indexOf(machineId) < 0 &&
        activations.length >= parsed.maxPc
      ) {
        return {
          ok: false,
          error: "기업용 키 PC 5대 한도에 도달했습니다. support@humateck.com",
        };
      }
      saveEntActivation(parsed.key, machineId);
    }

    var record = {
      key: parsed.key,
      edition: parsed.edition,
      maxPc: parsed.maxPc,
      machineId: machineId,
      activatedAt: new Date().toISOString(),
    };
    saveLicense(record);
    return { ok: true, license: record };
  }

  function isLicensed(expectedEdition) {
    var lic = loadLicense();
    if (!lic || !lic.key) return false;
    if (expectedEdition && lic.edition !== expectedEdition) return false;
    return parseKey(lic.key) !== null;
  }

  window.HumateckPcLicense = {
    activate: activate,
    isLicensed: isLicensed,
    load: loadLicense,
    getMachineId: getMachineId,
    parseKey: parseKey,
  };
})();
