(function () {
  "use strict";

  function $(id) {
    return document.getElementById(id);
  }

  function getEdition() {
    var gate = $("humateckPcLicenseGate");
    return gate ? gate.getAttribute("data-pc-edition") || "standard" : "standard";
  }

  function scrollToHero() {
    try {
      if (location.hash) {
        history.replaceState(null, "", location.pathname + location.search);
      }
    } catch (e) {}

    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;

    var hero = $("pcHero");
    if (hero && hero.scrollIntoView) {
      hero.scrollIntoView({ block: "start", behavior: "instant" });
    }
  }

  function keepHeroVisible() {
    scrollToHero();
    [50, 150, 400, 900].forEach(function (ms) {
      setTimeout(scrollToHero, ms);
    });
  }

  function showBootMessage(text) {
    var boot = $("humateckPcBootScreen");
    if (!boot) return;
    boot.removeAttribute("hidden");
    var p = boot.querySelector("p");
    if (p) p.textContent = text;
  }

  function hideGate() {
    var gate = $("humateckPcLicenseGate");
    if (gate) gate.setAttribute("hidden", "hidden");
    keepHeroVisible();
  }

  function showGate() {
    var gate = $("humateckPcLicenseGate");
    if (gate) gate.removeAttribute("hidden");
  }

  function tryActivate() {
    var keyEl = $("humateckPcLicenseKey");
    var statusEl = $("humateckPcLicenseStatus");
    if (!window.HumateckPcLicense) {
      if (statusEl) {
        statusEl.textContent = "라이선스 모듈을 불러오지 못했습니다.";
        statusEl.className = "pcLicenseStatus bad";
      }
      return;
    }
    var res = window.HumateckPcLicense.activate(
      keyEl ? keyEl.value : "",
      getEdition()
    );
    if (res.ok) {
      if (statusEl) {
        statusEl.textContent = "활성화 완료.";
        statusEl.className = "pcLicenseStatus";
      }
      hideGate();
      if (typeof window.humateckPcLoadRemoteApp === "function") {
        window.humateckPcLoadRemoteApp();
      } else {
        showGate();
        if (statusEl) {
          statusEl.textContent =
            "프로그램 모듈을 불러오지 못했습니다. ZIP을 다시 풀고 START.bat으로 실행하세요.";
          statusEl.className = "pcLicenseStatus bad";
        }
      }
    } else {
      if (statusEl) {
        statusEl.textContent = res.error || "활성화 실패";
        statusEl.className = "pcLicenseStatus bad";
      }
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    try {
      if ("scrollRestoration" in history) history.scrollRestoration = "manual";
    } catch (e) {}

    keepHeroVisible();

    var planJump = $("pcPlanSelectJump");
    if (planJump) {
      planJump.addEventListener("click", function (e) {
        e.preventDefault();
        var target = document.getElementById("planSelectSection");
        if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    }

    var btn = $("humateckPcLicenseActivateBtn");
    var keyEl = $("humateckPcLicenseKey");
    if (btn) btn.addEventListener("click", tryActivate);
    if (keyEl) {
      keyEl.addEventListener("keydown", function (e) {
        if (e.key === "Enter") tryActivate();
      });
    }

    if (
      window.HumateckPcLicense &&
      window.HumateckPcLicense.isLicensed(getEdition())
    ) {
      hideGate();
      if (typeof window.humateckPcLoadRemoteApp === "function") {
        window.humateckPcLoadRemoteApp();
      } else {
        showGate();
        var statusEl = $("humateckPcLicenseStatus");
        if (statusEl) {
          statusEl.textContent =
            "프로그램 모듈 오류. dist 폴더 ZIP을 새로 받아 다시 실행하세요.";
          statusEl.className = "pcLicenseStatus bad";
        }
      }
    } else {
      showGate();
    }
  });

  window.addEventListener("load", keepHeroVisible);
})();
