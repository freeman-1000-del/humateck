(function () {
  "use strict";

  var YOUTUBE_SCOPE = "https://www.googleapis.com/auth/youtube.force-ssl";
  var tokenClient = null;

  function $(id) {
    return document.getElementById(id);
  }

  function setAuthStatus(text, type) {
    var el = $("authStatus");
    if (!el) return;
    el.textContent = text || "";
    el.className = "status" + (type === "ok" ? " ok" : type === "bad" ? " bad" : "");
  }

  function getClientId() {
    var input = $("googleClientIdInput");
    return input ? String(input.value || "").trim() : "";
  }

  function waitForGoogle(callback) {
    var tries = 0;
    var timer = setInterval(function () {
      tries++;
      if (window.google && google.accounts && google.accounts.oauth2) {
        clearInterval(timer);
        callback();
      } else if (tries > 80) {
        clearInterval(timer);
        setAuthStatus("Google 인증 라이브러리를 불러오지 못했습니다.", "bad");
      }
    }, 150);
  }

  function startOAuth() {
    var clientId = getClientId();
    if (!clientId) {
      alert("Google OAuth Web Client ID를 입력하세요.");
      setAuthStatus("Client ID가 비어 있습니다.", "bad");
      return;
    }
    if (!/^https?:$/.test(window.location.protocol)) {
      alert(
        "OAuth는 file:// 에서 동작하지 않습니다. 시작.bat 으로 localhost에서 실행하세요."
      );
      setAuthStatus("현재 주소: " + window.location.origin, "bad");
      return;
    }

    waitForGoogle(function () {
      try {
        tokenClient = google.accounts.oauth2.initTokenClient({
          client_id: clientId,
          scope: YOUTUBE_SCOPE,
          prompt: "consent select_account",
          callback: function (response) {
            if (response && response.access_token) {
              window.humateckGoogleAccessToken = response.access_token;
              try {
                sessionStorage.setItem(
                  "humateckGoogleAccessToken",
                  response.access_token
                );
              } catch (e) {}
              setAuthStatus("OAuth 인증 완료. 등록을 진행할 수 있습니다.", "ok");
            } else {
              setAuthStatus(
                "인증 응답이 없습니다. Origins·Client ID를 확인하세요.",
                "bad"
              );
            }
          },
          error_callback: function (error) {
            setAuthStatus(
              "OAuth 실패: " + (error && error.type ? error.type : "unknown"),
              "bad"
            );
          },
        });
        tokenClient.requestAccessToken({ prompt: "consent select_account" });
        setAuthStatus("Google 창에서 승인(Allow)을 완료하세요.");
      } catch (e) {
        setAuthStatus("OAuth 시작 오류: " + (e.message || e), "bad");
      }
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    var btn = $("oauthStartBtn");
    if (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        startOAuth();
      });
    }
  });

  window.HumateckPcOAuth = { startOAuth: startOAuth };
})();
