param(
  [int]$Port = 8765,
  [string]$Root = (Join-Path $PSScriptRoot "app")
)

$ErrorActionPreference = "Stop"
$Root = (Resolve-Path $Root).Path
$servePs1 = Join-Path $PSScriptRoot "serve.ps1"
$stopPs1 = Join-Path $PSScriptRoot "stop-server.ps1"
$markerPath = Join-Path $Root "shared\pc-bootstrap.js"
$marker = "humateckPcLoadRemoteApp"

if (-not (Test-Path $markerPath)) {
  Write-Host "app folder not found: $Root" -ForegroundColor Red
  exit 1
}

if (Test-Path $stopPs1) {
  & $stopPs1 | Out-Null
}

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = "powershell.exe"
$psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -NoExit -File `"$servePs1`" -Port $Port -Root `"$Root`""
$psi.WorkingDirectory = $PSScriptRoot
$psi.UseShellExecute = $true
$null = [System.Diagnostics.Process]::Start($psi)

function Test-OurServer {
  try {
    $resp = Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:$Port/shared/pc-bootstrap.js" -TimeoutSec 3
    return ($resp.Content -match [regex]::Escape($marker)) -and ($resp.Content -match "__HUMATECK_PC_SHELL_VER__")
  } catch {
    return $false
  }
}

$ok = $false
Start-Sleep -Seconds 2
1..15 | ForEach-Object {
  if (Test-OurServer) {
    $ok = $true
    return
  }
  Start-Sleep -Seconds 1
}

if ($ok) {
  Start-Process "http://localhost:$Port/index.html"
  Write-Host "OK: http://localhost:$Port/index.html" -ForegroundColor Green
  exit 0
}

Write-Host ""
Write-Host "Server start failed (port $Port)." -ForegroundColor Red
Write-Host "Run STOP.bat, then START.bat again." -ForegroundColor Yellow
Write-Host "If still failing, restart PC." -ForegroundColor Yellow
Write-Host ""
exit 1
