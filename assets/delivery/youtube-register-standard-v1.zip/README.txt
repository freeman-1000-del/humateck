﻿YouTube Multilingual Register - Standard

1. Run STOP.bat (if you ran before), then START.bat
2. Enter license key (demo: HMT-STD-DEMO0001 / HMT-ENT-DEMO0001)
3. Google OAuth + register

Practice: https://humateck.com/deployer.html
Support: support@humateck.com
Internet required (loads UI from Humateck servers).
