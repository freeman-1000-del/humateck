﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1" -Port 8765 -Root "%~dp0app"
if errorlevel 1 pause
